<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tmw_desert_spacing" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="48" columns="8">
 <image source="tmw_desert_spacing.png" width="265" height="199"/>
 <terraintypes>
  <terrain name="wall" tile="-1"/>
 </terraintypes>
 <tile id="24" terrain=",,,0"/>
 <tile id="25" terrain=",,0,0"/>
 <tile id="26" terrain=",,0,"/>
 <tile id="32" terrain=",0,,0"/>
 <tile id="33" terrain="0,0,0,0"/>
 <tile id="34" terrain="0,,0,"/>
 <tile id="35" terrain="0,0,0,"/>
 <tile id="36" terrain="0,0,,0"/>
 <tile id="40" terrain=",0,,"/>
 <tile id="41" terrain="0,0,,"/>
 <tile id="42" terrain="0,,,"/>
 <tile id="43" terrain="0,,0,0"/>
 <tile id="44" terrain=",0,0,0"/>
</tileset>
