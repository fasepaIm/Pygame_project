<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="1e66a9f5eef998b3b1491145b8aff4d5--tile-ideas-sprites" tilewidth="32" tileheight="32" spacing="2" margin="4" tilecount="289" columns="17">
 <image source="1e66a9f5eef998b3b1491145b8aff4d5--tile-ideas-sprites.jpg" width="606" height="606"/>
</tileset>
